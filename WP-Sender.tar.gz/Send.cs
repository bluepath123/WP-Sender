using System;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using Newtonsoft.Json.Linq;
using System.Linq;


class Program
{
    private static readonly HttpClient httpClient = new();

    static async Task Main(string[] args)
    {
        // 配置信息
        string xmlRpcUrl = "https://xxxxxx.com/xmlrpc.php"; // 替换为你的WordPress网站的XML-RPC URL
        string username = "User"; // 替换为你的WordPress用户名
        string password = "Password"; // 替换为你的WordPress密码或应用密码
        string apiKey = "sk-xxxxxxxxxx"; // 替换为你的通义API Key

        Console.WriteLine("请输入文章标题（输入 'exit' 结束程序）：");

        while (true)
        {
            var title = Console.ReadLine();
            if (title?.ToLower() == "exit") break;

            // 生成文章内容
            var content = await GenerateContentAsync(title, apiKey);

            // 发布文章
            PublishPost(xmlRpcUrl, username, password, title, content, "", "");
        }
    }

    private static async Task<string> GenerateContentAsync(string title, string apiKey)
    {
        var url = "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions";
        var jsonContent = @$"{{
            ""model"": ""qwen-plus"",
            ""messages"": [
                {{
                    ""role"": ""user"",
                    ""content"": ""请根据以下标题生成一篇文章的内容，并以HTML格式返回：{title}""
                }}
            ]
        }}";

        using var content = new StringContent(jsonContent, Encoding.UTF8, "application/json");
        httpClient.DefaultRequestHeaders.Authorization = new("Bearer", apiKey);
        httpClient.DefaultRequestHeaders.Accept.Add(new("application/json"));

        HttpResponseMessage response = await httpClient.PostAsync(url, content);

        if (response.IsSuccessStatusCode)
        {
            var responseJson = await response.Content.ReadAsStringAsync();
            var responseObj = JObject.Parse(responseJson);
            return responseObj["choices"][0]["message"]["content"].ToString();
        }
        else
        {
            throw new Exception($"Error: {(int)response.StatusCode} {response.ReasonPhrase}");
        }
    }

    private static void PublishPost(string xmlRpcUrl, string username, string password, string title, string content, string categories, string tags)
    {
        var doc = new XDocument(
            new XElement("methodCall",
                new XElement("methodName", "metaWeblog.newPost"),
                new XElement("params",
                    new XElement("param",
                        new XElement("value",
                            new XElement("string", xmlRpcUrl)
                        )
                    ),
                    new XElement("param",
                        new XElement("value",
                            new XElement("string", username)
                        )
                    ),
                    new XElement("param",
                        new XElement("value",
                            new XElement("string", password)
                        )
                    ),
                    new XElement("param",
                        new XElement("value",
                            new XElement("struct",
                                new XElement("member", 
                                    new XElement("name", "title"),
                                    new XElement("value", new XElement("string", title))
                                ),
                                new XElement("member",
                                    new XElement("name", "description"),
                                    new XElement("value", new XElement("string", content))
                                ),
                                new XElement("member",
                                    new XElement("name", "categories"),
                                    new XElement("value", new XElement("array", 
                                        new XElement("data",
                                            categories.Split(',').Select(cat => new XElement("value", new XElement("string", cat.Trim())))
                                        )
                                    ))
                                ),
                                new XElement("member",
                                    new XElement("name", "mt_keywords"),
                                    new XElement("value", new XElement("string", tags))
                                )
                            )
                        )
                    ),
                    new XElement("param",
                        new XElement("value",
                            new XElement("boolean", "1") // 发布文章，如果是0则保存为草稿
                        )
                    )
                )
            )
        );

        var request = WebRequest.Create(xmlRpcUrl) as HttpWebRequest;
        request.Method = "POST";
        request.ContentType = "text/xml";
        byte[] bytes = Encoding.UTF8.GetBytes(doc.ToString());
        request.ContentLength = bytes.Length;

        using (var stream = request.GetRequestStream())
        {
            stream.Write(bytes, 0, bytes.Length);
        }

        try
        {
            using (var response = request.GetResponse() as HttpWebResponse)
            using (var reader = new System.IO.StreamReader(response.GetResponseStream()))
            {
                string result = reader.ReadToEnd();
                Console.WriteLine(result); // 输出响应结果
            }
        }
        catch (WebException ex)
        {
            if (ex.Response != null)
            {
                using (var errorResponse = (HttpWebResponse)ex.Response)
                using (var reader = new System.IO.StreamReader(errorResponse.GetResponseStream()))
                {
                    string error = reader.ReadToEnd();
                    Console.WriteLine($"Error: {error}"); // 错误处理
                }
            }
            else
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}